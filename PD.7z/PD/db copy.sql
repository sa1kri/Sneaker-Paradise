create table  user(
    id integer primary key,
    name TEXT,
    pezdey date,
    id_namber foreign key namber(id)
);
create table hospital (
    id int primary key,
    id_doctor foreign key doctor(id),
    cabinet integer,
    information foreign key user(id),
    namber integer,
);
create table doctor (
    id int primary key,
    name TEXT,
    information text,
    id_cabinet foreign key cabinet(id)
);
create table cabinet (
    id int primary key,
    house varchar(100),
    namber varchar(100)
);
create table namber(
    id int primary key,
    id_cabinet foreign key cabinet(id),
    time date,
    id_doctor foreign key doctor(id)
); 
package main

import (
	"database/sql"
	"io/ioutil"
	"log"
	"os"
	//_"github.com/mattn/go-sqlite3"
)

func main() {
	filePath := "database.db"

	os.Remove(filePath)

	log.Printf("Creating %s", filePath)

	file, err := os.Create(filePath)
	if err != nil {
		log.Fatal(err.Error())
	}
	file.Close()

	log.Printf("%s created", filePath)

	sqliteDatabase, _ := sql.Open("sqlite3", filePath)
	if err != nil {
		log.Fatal(err.Error())
	}
	fileSql, err := ioutil.ReadFile("./db.sql")
	if err != nil {
		log.Fatal(err.Error)
	}
	log.Println(fileSql)

	sqliteDatabase.Close()
	//1 VAR
	//if _, err := sqliteDatabase.Exec(string(filePath)); err != nil {
	//	log.Fatal(err.Error())
	//}

	//2 VAR
	//_, err = gorm.Open(sqlie.Open(filePath), &gorm.Confic{})
	//if err != nil{
	//	log.Fatal(err.Error())
	//}

}

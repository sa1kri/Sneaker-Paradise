Create table If not exists user(
    id Integer primary key,
    name TEXT
);